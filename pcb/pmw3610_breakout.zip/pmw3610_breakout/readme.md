本データは、kumamuk.key氏（@kumamuk_key）作成のpwm3610_breakout_for_roBaを参考に、k.ki（@0002ozlet）が改変したものです。
<br>

https://github.com/kumamuk-git/roBa

<br>
使用する際は、githubのライセンスを確認してください。